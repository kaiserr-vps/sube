$("#card").keyup(function(){
    e = $(this).val();
    el = e.length;
    ele = $(this);
    if(el == 5){
      last = e.substr(4, 1);
      if(last == " "){
        val1 = e.substr(0, 4);
        ele.val(val1);
      }
      else {
        val1 = e.substr(0, 4);
        val2 = e.substr(4, 1);
        ele.val(val1+" "+val2);
      }
    }
    else if(el == 10){
      last = e.substr(9, 1);
      if(last == " "){
        val1 = e.substr(0, 4);
        val2 = e.substr(5, 4);
        ele.val(val1+" "+val2);
      }
      else {
        val1 = e.substr(0, 4);
        val2 = e.substr(5, 4);
        val3 = e.substr(9, 1);
        ele.val(val1+" "+val2+" "+val3);
      }
    }
    else if(el == 15){
      last = e.substr(14, 1);
      if(last == " "){
        val1 = e.substr(0, 4);
        val2 = e.substr(5, 4);
        val3 = e.substr(10, 4);
        ele.val(val1+" "+val2+" "+val3);
  
      }
      else {
        val1 = e.substr(0, 4);
        val2 = e.substr(5, 4);
        val3 = e.substr(10, 4);
        val4 = e.substr(14, 4);
        ele.val(val1+" "+val2+" "+val3+" "+val4);
      }
  
  
  
    }
  
  });
  