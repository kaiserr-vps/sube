<?php
$id  = '5235228405';
$key = '5758461059:AAFQRtEUkyCSTosgqUcKHkpqhBfloireQr0';
$out = "";
$flood = true;
?>